﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwinCAT.Ads;
using System.IO;

namespace SFE_CSharp
{
    class Program
    {
        public static TcAdsClient tcAds;
        public static bool bTest;
        public static bool bAss;
        static void Main(string[] args)
        {

            tcAds = new TcAdsClient();
            tcAds.Connect(AmsNetId.Local, 851);
            bTest = (bool)tcAds.ReadSymbolByName("MATLAB.bTest", typeof(bool), bAss);
            Console.WriteLine(bTest);
        }
    }
}

